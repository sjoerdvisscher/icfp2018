# icfp2018

Run `cabal install`
Then run `dist/build/icfp2018/icfp2018`
